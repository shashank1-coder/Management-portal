import React from 'react';
//import AddStudent from './AddStudent'; // Adjust the path as per your project structure
import './Home.css'; // Import CSS for styling
import Carousal from './Carousal';





const Home = () => {


  return (
    <>
     
      <div>
        <Carousal />
      </div>
      <div className='main-content'>
        
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sollicitudin nibh at mi cursus, nec vehicula neque tincidunt. Sed sed dictum mauris. Vestibulum sit amet lobortis odio. Donec sollicitudin vulputate dignissim. Maecenas pharetra justo et nisl imperdiet cursus. Quisque in orci sed leo imperdiet commodo. Maecenas tempor, metus eget ullamcorper gravida, sapien arcu porttitor ante, quis maximus leo justo ac libero. Praesent aliquet lacinia nisi, ac maximus urna pretium posuere. Curabitur lacinia pulvinar efficitur. Nullam efficitur dignissim nisi commodo hendrerit. Curabitur id metus rhoncus, auctor quam sit amet, posuere tortor. Vivamus convallis ac nulla quis venenatis. Ut rutrum ut justo nec dictum.

Etiam vitae ante vel turpis sollicitudin lacinia. Donec facilisis lobortis diam, at rhoncus lectus egestas id. Vestibulum pretium metus in molestie tincidunt. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean ultrices, dui id euismod pulvinar, orci neque semper lorem, ac euismod metus felis eu nunc. Morbi interdum at magna vel sagittis. Suspendisse blandit enim felis, id accumsan risus maximus vel. Donec ullamcorper quam quis finibus posuere. Curabitur interdum ex in nunc s</p>
      </div>
     
    </>
  );
};


export default Home;










/*


 <div className="form-container">
        <AddStudent />
      </div>




<div className="row">
    <div className="column middle" style={mystyle}>
      <h2 style={{color:"green"}}>ABOUT US  </h2>        
      <p>BITSILICA is an expeditiously expanding service organization, deeply rooted in the Semiconductor and Embedded industry.</p>
      <img src="C:\Users\bsath\Desktop\Server\bitsilica.jpg" style={{width:"1000", height:"500"}} alt=""/>
    </div>

    
    
    <div className="column side">
        <h2 style={{color:"green"}}>GOALS</h2>
        <p>At BITSILICA, we deliver excellence, ensuring that our clients always experience the best in the Semiconductor and Embedded industry. Our mission is to help our clients deliver the technologically advanced products of superior quality with challenging time to market and in the process build a world-class company that attracts, values, and retains quality talent.At BITSILICA, our vision is to empower businesses with innovative solutions and advanced technologies. We strive to be a global leader, driving transformation and enabling success in the Semicon and Embedded industries. Together, let's shape a future of limitless possibilities. Innovation. Excellence. Collaboration.
          We are driven by these core values, delivering exceptional solutions and fostering strong partnerships in the Semicon and Embedded industries.
          Innovation. Excellence. Collaboration.</p>
    </div>
</div> */