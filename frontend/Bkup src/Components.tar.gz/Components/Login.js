import React, { useState } from 'react';
import './Login.css';

const Login = () => {
  const [loginType, setLoginType] = useState('');

  const handleLoginType = (type) => {
    setLoginType(type);
  };

  return (
      <div className="container">
        <h1>Login</h1>
      <div className="login-container">
        <button onClick={() => handleLoginType('Student')} className="login-btn">Student Login</button>
        <button onClick={() => handleLoginType('Admin')} className="login-btn">Admin Login</button>
      </div>
      {loginType && (
        <form className="login-form">
          <h2>{loginType} Login</h2>
          <label htmlFor="username">Username</label>
          <input 
            type="text" 
            id="username" 
            name="username" 
            pattern="[A-Za-z0-9]+" 
            title="Username can only contain letters and numbers." 
            required 
          />
          <label htmlFor="password">Password</label>
          <input 
            type="password" 
            id="password" 
            name="password" 
            required 
          />
          <button type="submit">Login</button>
          <a href="/" id="createAccountLink">Create a New Account</a>
        </form>
      )}
    </div>
  );
};

export default Login;
