import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Courses() {
    const [courses, setCourses] = useState([]);

    useEffect(() => {
        const fetchCourses = async () => {
            try {
                const response = await axios.get('http://localhost:8000/courses');
                setCourses(response.data);
            } catch (error) {
                console.error('Error fetching courses:', error);
            }
        };

        fetchCourses();
    }, []);

    return (
        <div className='main-content'>
            <h1>Courses List</h1>
            <div className='std-body'>

            <div className='table-data'>
            <table>
                <thead>
                    <tr>
                        <th style={{paddingRight:"50px"}}>Course ID</th>
                        <br></br>
                        <th>Course Name</th>
                    </tr>
                </thead>
                <tbody>
                    {courses.map((course, courseIndex) => (
                        <tr key={course.id || courseIndex}>
                            <td >{course.id}</td>
                            <br></br>
                            <td  >{course.name}</td>
                            </tr>
                    ))}
                </tbody>
            </table>
            </div>
                    </div>
        </div>
    );
}

export default Courses;
